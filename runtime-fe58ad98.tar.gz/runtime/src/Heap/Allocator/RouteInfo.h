// Copyright (c) Huawei Technologies Co., Ltd. 2025. All rights reserved.
// This source file is part of the Cangjie project, licensed under Apache-2.0
// with Runtime Library Exception.
//
// See https://cangjie-lang.cn/pages/LICENSE for license information.


#ifndef MRT_ROUTE_INFO_H
#define MRT_ROUTE_INFO_H
namespace MapleRuntime {
} // namespace MapleRuntime
#endif // MRT_ROUTE_INFO_H
